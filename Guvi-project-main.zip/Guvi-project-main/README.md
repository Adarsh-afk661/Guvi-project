# Online Music Streaming App 🎵

## Overview
Streamify is a modern music streaming application where users can create accounts, login, and manage their playlists.

## Features
- User Registration/Login
- Playlist Creation
- Music Player Integration

## Tech Stack
- Backend: Java, JSP, JDBC
- Frontend: HTML, CSS, JS
- Database: MySQL
